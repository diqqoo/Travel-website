
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Tourism in Mangystau</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html"><i class="icon-map22"></i>Tourism in Mangystau</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
								<li><a href="home.php">Home</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Popular destination</a>
								<ul class="fh5co-sub-menu">
									<li><a href="vacation.php">Holy places</a></li>
									<li><a href="1.php">Tourist attractions</a></li>
									
								</ul>
							</li>
							<li><a href="index.php">Booking</a></li>
							<li class="active"><a href="events.php">Events</a></li>

						</ul>
					</nav>
				</div>
			</div>
		</header>

		<!-- end:header-top -->
	
		<div class="fh5co-hero">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover" data-stellar-background-ratio="0.5" style="background-image: url(https://www.aveneerdmc.com/sites/default/files/be%20inspired%20mangystau%204.jpg);">
				<div class="desc">
					<div class="container">
						<div class="row">
							<div class="col-sm-5 col-md-5">
								<!-- <a href="index.html" id="main-logo">Travel</a> -->
								<div class="tabulation animate-box">

								  <!-- Nav tabs -->
								 

								</div>
							</div>
							<div class="desc2 animate-box">
								
							
									<p><h2>Exclusive Tour in Mangystau</h2><p>
									<h3>Travel with us</h3>
									
									<!-- <p><a class="btn btn-primary btn-lg" href="#">Get Started</a></p> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		

		<div id="fh5co-car" class="fh5co-section-gray">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
						<h3>Tour "Peninsula Mangystau"</h3>
						<p>A tour of western Kazakhstan - "Mangystau Peninsula", will open new, incredible, space, alien views to lovers of active travel. It will acquaint you with the history, traditions of this harsh, deserted and hot land. In a pleasant, friendly atmosphere, in comfortable conditions, in a prepared off-road vehicle, we set off for new impressions and views!</p>
					</div>
				</div>
				<div class="row row-bottom-padded-md">
					<div class="col-md-6 animate-box">
						<div class="car">
							<div class="one-4">
								<h3>Bozzhyra tract</h3>
								<span class="price">7.800 tg<small> / adult</small></span>
								<span class="price">4.000 tg<small> / children</small></span>
								<span class="price">600 km<small> / duration</small></span>
								<span class="price">08:30 <small> / departure</small></span>
								<span class="price"><small>Bus, guide, food </small></span>
								<span class="price"><small>Every Sunday</small></span>
								<span class="price"><small>8707 980 0104 </small></span>
								
							</div>
							<div class="one-1" style="background-image: url(https://opt-727458.ssl.1c-bitrix-cdn.ru/upload/iblock/591/29.jpg?1613492173118450);">
							</div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<div class="car">
							<div class="one-4">
								<h3>Shakpak ata</h3>
								<span class="price">5.800 tg/ adult</small></span>
								<span class="price">3.000 tg<small> / children</small></span>
								<span class="price">260 km<small> / duration</small></span>
									<span class="price">08:30 <small> / departure</small></span>
								<span class="price"><small>Bus, guide, food</small></span>
								<span class="price"><small>Every Saturday</small></span>
								<span class="price"><small>8707 980 0104</small></span>
								

							</div>
							<div class="one-1" style="background-image: url(https://files.kazakhstan.travel/files/public/201811/15/264224f5bc8c461f87a33a77a98d26c8/%D0%A8%D0%B0%D0%BA%D0%BF%D0%B0%D0%BA-%D0%B0%D1%82%D0%B0.jpg);">
							</div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<div class="car">
							<div class="one-4">
								<h3>Sherkala</h3>
								<span class="price">5.800 tg<small> / adult</small></span>
								<span class="price">3.000 tg<small> / children</small></span>
								<span class="price">390 km<small> / duration</small></span>
									<span class="price">08:30 <small> / departure</small></span>
								<span class="price"><small>Bus, guide, food </small></span>
								<span class="price"><small>Every Monday</small></span>
								<span class="price"><small>8707 980 0104 </small></span>
							</div>
							<div class="one-1" style="background-image: url(https://files.kazakhstan.travel/files/public/201812/10/07b94f10a25a4cff81f184777df63b38/%D0%A8%D0%B5%D1%80%D0%BA%D0%B0%D0%BB%D0%B0.jpg);">
							</div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<div class="car">
							<div class="one-4">
								<h3>Tuzbaiyr</h3>
								<span class="price">5.800 tg<small> / adult</small></span>
								<span class="price">3.000 tg<small> / children</small></span>
								<span class="price">870 km<small> / duration</small></span>
									<span class="price">08:30 <small> / departure</small></span>
								<span class="price"><small>Bus, guide, food </small></span>
								<span class="price"><small>Every Tuesday</small></span>
								<span class="price"><small>8707 980 0104 </small></span>
							</div>
							<div class="one-1" style="background-image: url(https://img.tourister.ru/files/2/3/8/2/8/2/5/6/clones/870_580_fixedwidth.jpg);">
							</div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<div class="car">
							<div class="one-4">
								<h3>Tamshaly</h3>
								<span class="price">4.900 tg<small> / adult</small></span>
								<span class="price">2.500 tg<small> / children</small></span>
								<span class="price">340 km<small> / duration</small></span>
									<span class="price">08:30 <small> / departure</small></span>
								<span class="price"><small>Bus, guide, food </small></span>
								<span class="price"><small>Every Wednesday</small></span>
								<span class="price"><small>8707 980 0104 </small></span>
							</div>
							<div class="one-1" style="background-image: url(https://files.kazakhstan.travel/files/public/201910/07/8af865a943ef4d1887b51a5c0bb533c1/Kanon-Tamshaly.jpg);">
							</div>
						</div>
					</div>
					<div class="col-md-6 animate-box">
						<div class="car">
							<div class="one-4">
								<h3>Dolina sharov</h3>
								<span class="price">5.500 tg<small> / adult</small></span>
								<span class="price">2.250 tg<small> / children</small></span>
								<span class="price">260 km<small> / duration</small></span>
									<span class="price">08:30 <small> / departure</small></span>
								<span class="price"><small>Bus, guide, food </small></span>
								<span class="price"><small>Every Friday</small></span>
								<span class="price"><small>8707 980 0104 </small></span>
							</div>
							<div class="one-1" style="background-image: url(https://lh3.googleusercontent.com/proxy/C-ZiS1znShJNu69rorg8NWSqtSgpFcB8beDM6OZoFjfC0Fd30wWOuOVDI2oBv_J0N7dq47A1EtFTn3XMFsmHHRnc-CqTCi7sy4gYwHwwZ8g8);">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div id="fh5co-testimonial" style="background-image:url(images/img_bg_1.jpg);">
		<div class="container">
			<div class="row animate-box">
				<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
					<h2>Happy Clients</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quotes-right"></i></span></span>
							<p>&ldquo;
Thank you very much for a wonderful stay, everything was great. The organizers are just great. Keep it up. &rdquo;</p>
						</blockquote>
						<p class="author">Maratuly Bauyrzhan, Aktau <span class="subtext">Resident of Mangystau region</span></p>
					</div>
					
				</div>
				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quotes-right"></i></span></span>
							<p>&ldquo;A blue-black cloud crept up from the "wet corner" and burst into a powerful downpour. Lightning flashed, thunder rumbled, hailstones the size of good cherries rattled on the roof. My husband and I, sitting on the porch of the country house, watch the sky brighten after a downpour, how transparent streams of light summer rain pour over the branches and leaves of the apple tree.&rdquo;</p>
						</blockquote>
						<p class="author">Sungat Daribayev, Aktau <span class="subtext">Resident of Mangystau region</span></p>
					</div>
					
					
				</div>
				<div class="col-md-4">
					<div class="box-testimony animate-box">
						<blockquote>
							<span class="quote"><span><i class="icon-quotes-right"></i></span></span>
							<p>&ldquo;Lead clouds that covered Mangyshlak gave a special painting - no matter how we hoped, the weather did not clear up. We were gathering dust along the crooked steppe paths - now on the upper surface of the chink, watching deep cliffs from the windows of cars, then going down to the white chalk surface overgrown with sparse greenery.&rdquo;</p>
						</blockquote>
						<p class="author">Sarsenbayeva Kamshat, Aktau <span class="subtext">Resident of Mangystau region</span></p>
					</div>
					
				</div>
			</div>
		</div>
	</div>
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>About Mangystau</h3>
							<p>Mangystau region is located in southwestern Kazakhstan, east of the Caspian Sea to the plateau Mangyshlak.</p>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top popular destination</h3>
							<ul>
								<li><a href="#">Bozzhyra</a></li>
								<li><a href="#">Saura</a></li>
								<li><a href="#">Tamzhaly</a></li>
								<li><a href="#">Karakol</a></li>
								<li><a href="#">Zhygylgan</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top Hotels</h3>
							<ul>
								<li><a href="#">Rixos Water World</a></li>
								<li><a href="#">Holiday Inn</a></li>
								<li><a href="#">Otel</a></li>
								<li><a href="#">Renaissance</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Holy places</h3>
							<ul>
								<li><a href="#">Beket-Ata</a></li>
								<li><a href="#">Otpan-Tau</a></li>
								<li><a href="#">Sherkala</a></li>
								<li><a href="#">Usturt</a></li>
								<li><a href="#">Sultan-Epe</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Booking</h3>
							<ul>
								<li><a href="#">Booking hotels</a></li>
								<li><a href="#">Booking taxis</a></li>
							</ul>	
							</div>
							<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Contact us</h3>
							<ul>
								<li><a href="#">+77757757575</a></li>
							
							</ul>
						</div>
							</ul>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							
						</div>
					</div>
				</div>
			</div>
		</footer>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>


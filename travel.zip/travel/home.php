
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Tourism in Mangystau</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html"><i class="icon-map22"></i>Tourism in Mangystau</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li class="active"><a href="home.php">Home</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Popular destination</a>
								<ul class="fh5co-sub-menu">
									<li><a href="vacation.php">Holy places</a></li>
									<li><a href="1.php">Tourist attractions</a></li>
									
								</ul>
							</li>
							<li><a href="index.php">Booking</a></li>
							<li><a href="events.php">Events</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>

		<!-- end:header-top -->
	
		<div class="fh5co-hero">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover" data-stellar-background-ratio="0.5" style="background-image: url(https://www.aveneerdmc.com/sites/default/files/be%20inspired%20mangystau%202.jpg);">
				<div class="desc">
					<div class="container">
						<div class="row">
							<div class="col-sm-5 col-md-5">
								<div class="tabulation animate-box">

								

								</div>
							</div>
							<div class="desc2 animate-box">
									
									<p><h2>Mangystau Province</h2></p>
<h3>Millions of years ago the Tethys Ocean covered this land. Its remnants, fossils of long extinct species, are easy to find today. Vast clay deserts, salt pans, limestone mountains… You will remember these unearthly landscapes for years to come</h3>									
									<!-- <p><a class="btn btn-primary btn-lg" href="#">Get Started</a></p> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		
		<div id="fh5co-tours" class="fh5co-section-gray">
			

		<div id="fh5co-features">
			<div class="container">
				<div class="row">
					<div class="col-md-4 animate-box">

						<div class="feature-left">
							<span class="icon">
								<i class="icon-search"></i>
							</span>
							<div class="feature-copy">
								<h3>Booking hotel</h3>
								<p>Book a hotel online. Hotels from budget to luxury. Good rates. No reservation costs.</p>
								<p><a href="#">Learn More</a></p>
							</div>
						</div>

					</div>

					<div class="col-md-4 animate-box">
						<div class="feature-left">
							<span class="icon">
								<i class="icon-search"></i>
							</span>
							<div class="feature-copy">
								<h3>Go to events</h3>
								<p>You can buy last minute events at very competitive prices. Do not be afraid to purchase such tours, because you risk nothing!</p>
								<p><a href="events.html">Learn More</a></p>
							</div>
						</div>
					</div>
					<div class="col-md-4 animate-box">
						<div class="feature-left">
							<span class="icon">
								<i class="icon-search"></i>
							</span>
							<div class="feature-copy">
								<h3>Booking taxis</h3>
								<p>Get all types of cheap taxi booking services at lowest fare. Travel in Mangystau without troubles.</p>
								<p><a href="#">Learn More</a></p>
							</div>
						</div>
					</div>
				</div>
				
					</div>
				</div>
			</div>
		</div>

		
		<div id="fh5co-destination">
			<div class="tour-fluid">
				<div class="row">
					<div class="col-md-12">
						<ul id="fh5co-destination-list" class="animate-box">
							<li class="one-forth text-center" style="background-image: url(https://kursiv.kz/sites/default/files/users/user573/IMG_20190831_164503.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Aktau</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://weproject.media/upload/medialibrary/3d1/3d129a2e8736b3f8c61d2e9880ccc78d.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Rixos Water World</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://www.aveneerdmc.com/sites/default/files/be%20inspired%20mangystau%201.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Bozzhyra tract</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://img.itinari.com/pages/images/original/c2df4cf9-2a28-4e28-b5ff-2fc4ff35a762-vodkomotornik-ru-valera-cover.jpg?ch=DPR&dpr=1&w=1200&h=800&s=2cbe0a0d6448e39f97f37a0461506f89); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Golubaiya Bukhta</h2>
									</div>
								</a>
							</li>

							<li class="one-forth text-center" style="background-image: url(http://photos.wikimapia.org/p/00/04/61/51/93_big.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Saura</h2>
									</div>
								</a>
							</li>
							<li class="one-half text-center">
								<div class="title-bg">
									<div class="case-studies-summary">
										<h2>Most Popular Destinations</h2>
										<span><a href="#">View All Destinations</a></span>
									</div>
								</div>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://files.kazakhstan.travel/files/public/201910/07/8af865a943ef4d1887b51a5c0bb533c1/Kanon-Tamshaly.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Tamshaly</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://img.itinari.com/pages/images/original/3dfb2b84-dd85-499f-94cb-15bdad3260fb-1599px-baker_ata.jpg?ch=DPR&dpr=1&w=1200&h=800&s=3faf8dfc1cb465cfac81e5564fd8af2d); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Beket-Ata</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://www.lada.kz/uploads/photos/2021-04/1618465476.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Zhygylgan</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://images11.esquire.ru/upload/img_cache/037/037408085e6e41a4fab9ee49960b8f3c_ce_1731x1080x191x0_cropped_960x600.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Karakol</h2>
									</div>
								</a>
							</li>
							<li class="one-forth text-center" style="background-image: url(https://centralasia-adventures.com/image/new/mangistau.jpg); ">
								<a href="#">
									<div class="case-studies-summary">
										<h2>Dolina sharov</h2>
									</div>
								</a>
							</li>
						</ul>		
					</div>
				</div>
			</div>
		</div>

		<!-- fh5co-blog-section -->

		 
     <br>  <footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>About Mangystau</h3>
							<p>Mangystau region is located in southwestern Kazakhstan, east of the Caspian Sea to the plateau Mangyshlak.</p>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top popular destination</h3>
							<ul>
								<li><a href="#">Bozzhyra</a></li>
								<li><a href="#">Saura</a></li>
								<li><a href="#">Tamzhaly</a></li>
								<li><a href="#">Karakol</a></li>
								<li><a href="#">Zhygylgan</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top Hotels</h3>
							<ul>
								<li><a href="#">Rixos Water World</a></li>
								<li><a href="#">Holiday Inn</a></li>
								<li><a href="#">Otel</a></li>
								<li><a href="#">Renaissance</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Holy places</h3>
							<ul>
								<li><a href="#">Beket-Ata</a></li>
								<li><a href="#">Otpan-Tau</a></li>
								<li><a href="#">Sherkala</a></li>
								<li><a href="#">Usturt</a></li>
								<li><a href="#">Sultan-Epe</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Booking</h3>
							<ul>
								<li><a href="#">Booking hotels</a></li>
								<li><a href="#">Booking taxis</a></li>
							</ul>	
							</div>
							<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Contact us</h3>
							<ul>
								<li><a href="#">+77757757575</a></li>
							
							</ul>
						</div>
							</ul>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							
						</div>
					</div>
				</div>
			</div>
		</footer>
    </div>
</div>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>


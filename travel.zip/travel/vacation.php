<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Tourism in Mangystau</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
	<meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
	<meta name="author" content="FREEHTML5.CO" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html"><i class="icon-airplane"></i>Tourism in Mangystau</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li><a href="home.php">Home</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Popular destination</a>
								<ul class="fh5co-sub-menu">
									<li class="active"><a href="vacation.php">Holy places</a></li>
									<li><a href="1.php">Tourist attractions</a></li>
									
								</ul>
							</li>
							<li><a href="index.php">Booking</a></li>
							<li><a href="events.php">Events</a></li>

						</ul>
					</nav>
				</div>
			</div>
		</header>

		<!-- end:header-top -->
	
		<div class="fh5co-hero">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover" data-stellar-background-ratio="0.5" style="background-image: url(https://putidorogi-nn.ru/images/stories/aziya/kazahstan/mangistau_8.jpg);">
				<div class="desc">
					<div class="container">
						<div class="row">
							<div class="col-sm-5 col-md-5">
								<div class="tabulation animate-box">

								

								</div>
							</div>
							<div class="desc2 animate-box">
									
									<p><h2>Holy Places</h2></p>
<h3>You can see holy places, underground mosques,canyons,Ustyrt plateau and others.Mangystau is rich in architectural monuments than any other regions of our republic, which have been preserved to these days.</h3>
									<!-- <p><a class="btn btn-primary btn-lg" href="#">Get Started</a></p> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
		

		
	<div id="fh5co-blog-section" class="fh5co-section-gray">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
						<h3></h3>
						<p>The jewels of Mangystau are the underground mosques - Beket Ata, Shakpak Ata, Shopan Ata, Sultan Epe and others, which attract many believers and travelers all over Kazakhstan and the world.</p>
					</div>
				</div>
			</div>
			<div class="container">
				<div class="row row-bottom-padded-md">
					<div class="col-lg-4 col-md-4 col-sm-6">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="https://mangystau.inmap.kz/uploads/images/large_barak__948d83ea9d2bccf4bb893308eff9d396.jpg" alt=""></a>
							<div class="blog-text">
								<div class="prod-title">
									<h3><a href="#">Hazret Erzhan Burial</a></h3>
									
									<p>located in Tupkaragan district, Mangistau region, 30 km to the north-east of Tauchik village.
Coordinates: N 44°26' 16.74" , E 51° 8' 8.46"
Description of the Monument: It is currently included in the list of national historical and cultural monuments of local value by Order no. 3 dated January 5, 2018 by Mangistau Regional Akimat.</p>
								</div>
							</div> 
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-6">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="https://mangystau.inmap.kz/uploads/images/large_sultanupe3__954d5c92feb1997239a140e517125c37.jpg" alt=""></a>
							<div class="blog-text">
								<div class="prod-title">
									<h3><a href="#">Sultan-Epe Underground Mosque</a></h3>
								
									<p>Location: Mangistau district, Mangistau region, 30 km to the north-west from Tauchik village.
Coordinates: N 44°28' 18.97" , E 51°0' 36.72"
Description of the Monument: In 1982 the necropolis was included in the governmental records with local status. Pilgrimage begins with a symbolic burial of the saint Sultan-Epe, made of stone fence of round shape with stuck wooden staves</p>
								</div>
							</div> 
						</div>
					</div>
					<div class="clearfix visible-sm-block"></div>
					<div class="col-lg-4 col-md-4 col-sm-6">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="https://mangystau.inmap.kz/uploads/images/large_shopanata4__1b27c3a788b67025d692d213f4a31b30.jpg" alt=""></a>
							<div class="blog-text">
								<div class="prod-title">
									<h3><a href="#">Shopan Ata Necropolis and Underground Mosque</a></h3>
									
									<p>Location: Kuryk district, Mangistau region, 20 kilometres to the north-west from Senek village, along Khoresm caravan track.
Coordinates: N 43°32' 49.88" , E 53°23' 36.47"
History: For the first time the monument was surveyed in 1951-1952 by architectural research expedition led by architect M. M. Mendikulov</p>
								</div>
							</div> 
						</div>
					</div>
					</div>
					
					<div class="clearfix visible-sm-block"></div>
					<div class="col-lg-4 col-md-4 col-sm-6">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="https://mangystau.inmap.kz/uploads/images/large_beketata5__aae9aab16c5022016421f198470c5e24.jpg" alt=""></a>
							<div class="blog-text">
								<div class="prod-title">
									<h3><a href="#">Becket-Ata Underground Mosque in Oglandy (18th-19th centuries)</a></h3>
									
									<p>Location: Mangistau district in Mangistau region, 30 km to the south from Kyzan village.
Coordinates: N 44°39' 12.83" , E 52°27' 15.96"
Description of the Monument: Studied by expedition of Mangistau National Historical and Cultural Reserve in 2004 under the direction of K. Kanissova.</p>
								</div>
							</div> 
						</div>
					</div>
					<div class="clearfix visible-sm-block"></div>
					<div class="col-lg-4 col-md-4 col-sm-6">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="https://mangystau.inmap.kz/uploads/images/large_adaiata3__6761150f5a8415b606093786562939a7.jpg" alt=""></a>
							<div class="blog-text">
								<div class="prod-title">
									<h3><a href="#">Otpan Tau Historical and Cultural Complex</a></h3>
									
									<p>Location: Located in Mangistau district of Mangistau region, 15 km to the east from the village of Zhyngyldy.
Coordinates: N 44°11' 27.45" , E 51°53' 17.58"
Description of the Monument: The author of the idea and scientific concept for construction of the spiritual complex Otpan is a well-known poet and public figure Sabyr Aday.</p>
								</div>
							</div> 
						</div>
					</div>
					<div class="clearfix visible-sm-block"></div>
					<div class="col-lg-4 col-md-4 col-sm-6">
						<div class="fh5co-blog animate-box">
							<a href="#"><img class="img-responsive" src="https://mangystau.inmap.kz/uploads/images/large_sisemata2__a72aaff3ed2451ab9abed29e3be49f0a.jpg" alt=""></a>
							<div class="blog-text">
								<div class="prod-title">
									<h3><a href="#">Sissem-Ata Necropolis</a></h3>
									
									<p>Location: located in Mangistau district of Mangistau region, 35 km to the north from Otess village.
Coordinates: N 44°37' 15.36" , E 53°34' 50.10"
Description of the Monument: The monument was first taken under the state protection upon Resolution no. 38 by the Council of Ministers of the Kazakh SSR dated 20.01.1982.</p>
									
								</div>
							</div> 
						</div>
					</div>
					
					<div class="clearfix visible-md-block"></div>
				</div>
				</div>

				<div class="col-md-12 text-center animate-box">
					<p><a class="btn btn-primary btn-outline btn-lg" href="1.php">See tourist attractions <i class="icon-arrow-right22"></i></a></p>
				</div>

			</div>
		</div>
		<>
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>About Mangystau</h3>
							<p>Mangystau region is located in southwestern Kazakhstan, east of the Caspian Sea to the plateau Mangyshlak.</p>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top popular destination</h3>
							<ul>
								<li><a href="#">Bozzhyra</a></li>
								<li><a href="#">Saura</a></li>
								<li><a href="#">Tamzhaly</a></li>
								<li><a href="#">Karakol</a></li>
								<li><a href="#">Zhygylgan</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top Hotels</h3>
							<ul>
								<li><a href="#">Rixos Water World</a></li>
								<li><a href="#">Holiday Inn</a></li>
								<li><a href="#">Otel</a></li>
								<li><a href="#">Renaissance</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Holy places</h3>
							<ul>
								<li><a href="#">Beket-Ata</a></li>
								<li><a href="#">Otpan-Tau</a></li>
								<li><a href="#">Sherkala</a></li>
								<li><a href="#">Usturt</a></li>
								<li><a href="#">Sultan-Epe</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Booking</h3>
							<ul>
								<li><a href="#">Booking hotels</a></li>
								<li><a href="#">Booking taxis</a></li>
							</ul>	
							</div>
							<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Contact us</h3>
							<ul>
								<li><a href="#">+77757757575</a></li>
							
							</ul>
						</div>
							</ul>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							
						</div>
					</div>
				</div>
			</div>
		</footer>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>


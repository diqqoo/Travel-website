<?php
$server = "localhost";
$login = "root";
$password = "";
$database = "hotels";
$link = mysqli_connect($server, $login, $password, $database);

$result = mysqli_query($link, "SELECT * FROM `hotels`");

?>

<!DOCTYPE html>

 <html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Tourism in Mangystau</title>
	<link rel="shortcut icon" href="favicon.ico">
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	<link rel="stylesheet" href="css/animate.css">
	<link rel="stylesheet" href="css/icomoon.css">
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="css/superfish.css">
	<link rel="stylesheet" href="css/magnific-popup.css">
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">	
	<link rel="stylesheet" href="css/style.css">
	<script src="js/modernizr-2.6.2.min.js"></script>

	</head>

	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html"><i class="icon-map22"></i>Tourism in Mangystau</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li><a href="home.php">Home</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Popular destination</a>
								<ul class="fh5co-sub-menu">
									<li><a href="vacation.php">Holy places</a></li>
									<li><a href="1.php">Tourist attractions</a></li>
									
								</ul>
							</li>
							<li class="active"><a href="index.php">Booking</a></li>
							<li><a href="events.php">Events</a></li>

						</ul>
					</nav>
				</div>
			</div>
		</header>

	<div class="fh5co-hero">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover" data-stellar-background-ratio="0.5" style="background-image: url(https://img.poehalisnami.kz/static/hotels/kazakhstan/aktau/h276764/orig/276764_637310517387136294.jpg);">
			<div class="desc">
					<div class="container">
						<div class="row">
							<div class="col-sm-5 col-md-5">							
								<div class="tabulation animate-box">
								   <ul class="nav nav-tabs" role="tablist">
								      <li role="presentation" class="active">
								      	<a href="#hotel" aria-controls="hotel" role="tab" data-toggle="tab">Hotels</a>
								      </li>
								      <li role="presentation">
								    	   <a href="#taxi" aria-controls="taxi" role="tab" data-toggle="tab">Taxi</a>
								      </li>
								   </ul>

								<div class="tab-content">
									 <div role="tabpanel" class="tab-pane active" id="hotel">
										<div class="row">
											<form  action="hotel.php" method="GET">
											<div class="col-xxs-12 col-xs-6 mt">
												<section>
													<label for="class">Choose city:</label>
													<select class="cs-select cs-skin-border" name="city">
														<option value="" disabled selected>City</option>
														<option value="Aktau">Aktau</option>
														<option value="Ozen">Ozen</option>
														
													</select>
												</section>
											</div>
                                                <div class="col-xxs-12 col-xs-6 mt">
												<section>
													<label for="class">Choose hotel:</label>
													<select class="cs-select cs-skin-border" name="hotel">
														<option value="" disabled selected>Hotels</option>
														<option value="Rixos Water World">Rixos</option>
														<option value="Holiday Inn">Holiday Inn</option>
														<option value="Renaissance">Rennaisance</option>
														<option value="Caspian Rivera">Caspian Rivera</option>
														<option value="Grand Victory">Grand Victory</option>
														<option value="Bastau">Bastau</option>
														<option value="Aksaray">Aksaray</option>
														
													</select>
												</section>
											</div>
										
											<div class="col-xs-12">
												<input type="submit" class="btn btn-primary btn-block" value="Search" >
											</div>
													</form>
										</div>
									 </div>
									 
							
									 <div role="tabpanel" class="tab-pane active" id="taxi">
										<div class="row">
											<form  action="taxis.php" method="GET">
											<div class="col-xxs-12 col-xs-6 mt">
												<section>
													<label for="class">Choose city:</label>
													<select class="cs-select cs-skin-border" name="city">
														<option value="" disabled selected>City</option>
														<option value="Aktau">Aktau</option>
														<option value="Ozen">Ozen</option>
														
													</select>
												</section>
											</div>
											<div class="col-xs-12">
												<input type="submit" class="btn btn-primary btn-block" value="Search" >
											</form>
											</div>
											
										</div>
										
									 </div>
									</div>

								</div>
							</div>
									
							<div class="desc2 animate-box">
								<div class="col-sm-7 col-sm-push-1 col-md-7 col-md-push-1">
									<h2>Exclusive Booking Hotel</h2>
									<h3>Make your dreams of luxury getaway a reality. Book your room now!</h3>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

		</div>
						
				
	
	
<footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>About Mangystau</h3>
							<p>Mangystau region is located in southwestern Kazakhstan, east of the Caspian Sea to the plateau Mangyshlak.</p>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top popular destination</h3>
							<ul>
								<li><a href="#">Bozzhyra</a></li>
								<li><a href="#">Saura</a></li>
								<li><a href="#">Tamzhaly</a></li>
								<li><a href="#">Karakol</a></li>
								<li><a href="#">Zhygylgan</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top Hotels</h3>
							<ul>
								<li><a href="#">Rixos Water World</a></li>
								<li><a href="#">Holiday Inn</a></li>
								<li><a href="#">Otel</a></li>
								<li><a href="#">Renaissance</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Holy places</h3>
							<ul>
								<li><a href="#">Beket-Ata</a></li>
								<li><a href="#">Otpan-Tau</a></li>
								<li><a href="#">Sherkala</a></li>
								<li><a href="#">Usturt</a></li>
								<li><a href="#">Sultan-Epe</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Booking</h3>
							<ul>
								<li><a href="#">Booking hotels</a></li>
								<li><a href="#">Booking taxis</a></li>
							</ul>	
							</div>
							<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Contact us</h3>
							<ul>
								<li><a href="#">+77757757575</a></li>
							
							</ul>
						</div>
							</ul>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							
						</div>
					</div>
				</div>
			</div>
		</footer>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>


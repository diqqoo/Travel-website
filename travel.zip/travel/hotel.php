<?php

$server = "localhost";
$login = "root";
$password = "";
$database = "hotels";
$link = mysqli_connect($server, $login, $password, $database);


$name = $_GET['hotel'];
$city = $_GET['city'];

$sql = "SELECT * from hotels where hotel_name = '$name' and hotel_city='$city'";

$result = mysqli_query($link, $sql);

?>

<!DOCTYPE html>

<html class="no-js">
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Booking</title>

	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">
	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">
	<!-- Date Picker -->
	<link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
	<!-- CS Select -->
	<link rel="stylesheet" href="css/cs-select.css">
	<link rel="stylesheet" href="css/cs-skin-border.css">
	
	<link rel="stylesheet" href="css/style.css">

	<script src="js/modernizr-2.6.2.min.js"></script>


	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">

		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html"><i class="icon-map22"></i>Tourism in Mangystau</a></h1>

					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li><a href="home.php">Home</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Popular destination</a>
								<ul class="fh5co-sub-menu">
									<li><a href="vacation.php">Holy places</a></li>
									<li><a href="1.php">Tourist attractions</a></li>
									
								</ul>
							</li>
							<li class="active"><a href="index.php">Booking</a></li>
							<li><a href="events.php">Events</a></li>

						</ul>
					</nav>
				</div>
			</div>
		</header>
		

		<div id="fh5co-tours" class="fh5co-section-gray">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center heading-section animate-box">
						<h3>Hotel you want:</h3>
						<p>
						<?php 
							echo "<b>". $name ."</b>" . " hotel located in <b>". $city . "</b>";
						?>
						</p>
					</div>
				</div>
				<div class="row row-bottom-padded-md">

				<?php

				if (mysqli_num_rows($result) > 0) {
  					while($row = mysqli_fetch_assoc($result)) {
						echo "<div class='desc text-center'>";
						echo "<img src='" . $row["image"]."'>;". "<br>";
						echo "</div>";
				echo "</div>";
				
			
				
				echo "<div class='row'>";
					echo " <div class='col-md-12 animate-box'>";
						
					echo "</div>";
					echo "<div class='col-md-6 animate-box'>";
					
						echo "<br>";


													echo "<form  action='hotels.php' method='POST'>";
														echo "<h3>" . "Book now". "</h3>"; 
														
													echo "<label>Your name</label><br>";
													echo "<input type='text' name='firstname' size= '50'><br>";
													echo "<label>Your Mobile number</label><br>";
													echo "<input type='tel' name='tel' size= '50'><br>";
													echo "<label>Choose city</label><br>";
													echo "<input type='text' name='city' size= '50' value='".$row["hotel_city"]."'><br>";
													echo "<label>Choose hotel</label><br>";
													echo "<input type='text' name='hotel' size= '50' value = '".$row["hotel_name"]."'><br>";
													echo "<label>Choose number of rooms</label><br>";
													echo "<input type='number' name='rooms'  style='width: 425px;'><br>";
													echo "<label>Choose number of Adults</label><br>";
													echo "<input type='number' name='adult' style='width: 425px;'><br>";
													echo "<label>Choose number of Children</label><br>";
													echo "<input type='number' name='children'  style='width: 425px;'><br>";
													echo "<label>Choose Come Date</label><br>";
													echo "<input type='date' name='datecome'  style='width: 425px;'><br>";
													echo "<label>Choose Out Date</label><br>";
													echo "<input type='date' name='dateout' style='width: 425px;'><br><br>";
												echo " <input type='submit' class='btn btn-primary btn-block' value='Book Now' style='width: 425px;'>";
												echo "</form>";
					echo "</div>";
					
					
			
	echo "<br>";				
				echo "<div class='col-md-6'>";
							echo "<h3 class='section-title'>" . "About Hotel". "</h3>";
							echo "<ul class='contact-info'>";
								echo "<li>" . "</i>". $row["hotel_info1"]. "</li>";
								echo "<li>" . "</i>". $row["hotel_info2"]. "</li>";
								echo "<li>" . "</i>". $row["hotel_info3"]. "</li>";
								echo "<li>" . "</i>". $row["hotel_info4"]. "</li>";
								echo "<li>" . "</i>". $row["hotel_info5"]. "</li>";
								echo "<li>" . "</i>". $row["hotel_info6"]. "</li>";
								echo "<li>" . "</i>". $row["hotel_info7"]. "</li>";
								
							echo "</ul>";
						echo "</div>";
					
				echo "</div>";
	
	
	
	
		
		  					}	
				} 

		else {
  				echo "Wrong city and Hotel";
				}

				?>

</div>
</div>

		
		 <footer>
			<div id="footer">
				<div class="container">
					<div class="row row-bottom-padded-md">
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>About Mangystau</h3>
							<p>Mangystau region is located in southwestern Kazakhstan, east of the Caspian Sea to the plateau Mangyshlak.</p>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top popular destination</h3>
							<ul>
								<li><a href="#">Bozzhyra</a></li>
								<li><a href="#">Saura</a></li>
								<li><a href="#">Tamzhaly</a></li>
								<li><a href="#">Karakol</a></li>
								<li><a href="#">Zhygylgan</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Top Hotels</h3>
							<ul>
								<li><a href="#">Rixos Water World</a></li>
								<li><a href="#">Holiday Inn</a></li>
								<li><a href="#">Otel</a></li>
								<li><a href="#">Renaissance</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Holy places</h3>
							<ul>
								<li><a href="#">Beket-Ata</a></li>
								<li><a href="#">Otpan-Tau</a></li>
								<li><a href="#">Sherkala</a></li>
								<li><a href="#">Usturt</a></li>
								<li><a href="#">Sultan-Epe</a></li>
							</ul>
						</div>
						<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Booking</h3>
							<ul>
								<li><a href="#">Booking hotels</a></li>
								<li><a href="#">Booking taxis</a></li>
							</ul>	
							</div>
							<div class="col-md-2 col-sm-2 col-xs-12 fh5co-footer-link">
							<h3>Contact us</h3>
							<ul>
								<li><a href="#">+77757757575</a></li>
							
							</ul>
						</div>
							</ul>
						</div>
						
					</div>
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							
						</div>
					</div>
				</div>
			</div>
		</footer>

	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Date Picker -->
	<script src="js/bootstrap-datepicker.min.js"></script>
	<!-- CS Select -->
	<script src="js/classie.js"></script>
	<script src="js/selectFx.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>

	</body>
</html>


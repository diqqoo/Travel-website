CREATE TABLE `hotels` (
  `id` int(8) NOT NULL,
  `hotel_name` varchar(255) NOT NULL,
  `hotel_city` varchar(255) NOT NULL,
  `image` text NOT NULL,
  `price` double(10,2) NOT NULL,
  `hotel_info1` varchar(255) NOT NULL,
  `hotel_info2` varchar(255) NOT NULL,
  `comment1` varchar(255) NOT NULL,
  `comment1a` varchar(255) NOT NULL,
  `comment2` varchar(255) NOT NULL,
  `comment2a` varchar(255) NOT NULL,
  `comment3` varchar(255) NOT NULL,
  `comment3a` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `hotels` (`id`, `hotel_name`, `hotel_city`, `image`, `price`, `hotel_info1`, `hotel_info2`, `comment1`, `comment1a`, `comment2`, `comment2a`,`comment3`,`comment3a`) VALUES
(1, 'Rixos Carlton', 'Aktau', 'hotels/rixos.jpg', 1500.00, 'Rixos Carltaon is located in Aktau is good hotel, because there are many good things.', 'Yes, it is so', 'Rixos is good hotel', 'Rakhat Abdimanat', 'Rixos is normal hotel','NurSultan Khaimuldin','Rixos is worst hotel','Amanda King'),
(2, 'Khadisha', 'Aktau', 'hotels/khadisha.jpg', 800.00, 'Khadisha is located in Aktau is good hotel', 'Yes, it is so', 'Khadisha is good hotel', 'Rakhat Abdimanat', 'Khadisha normal hotel','Nursultan Khaimuldin','Comment about hotel','Angela Merkel'),
(3, 'Hilton', 'Aktau', 'hotels/hilton.jpg', 300.00, 'info1', 'info2', 'com1', 'a1', 'com2','a2','com3','a3'),
(4, 'Diamond', 'Aktau', 'hotels/diamond.jpg', 700.00, 'info1', 'info2', 'com1', 'a1', 'com2','a2','com3','a3'),
(5, 'Tumar', 'Ozen', 'hotels/tumar.jpg', 805.00, 'info1', 'info2', 'com1', 'a1', 'com2','a2','com3','a3'),
(6, 'Neal', 'Ozen', 'hotels/neal.jpg', 100.00, 'info1', 'info2', 'com1', 'a1', 'com2','a2','com3','a3');

CREATE TABLE `taxi` (
  `id` int(8) NOT NULL,
  `taxi_city` varchar(255) NOT NULL,
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


INSERT INTO `taxi` (`id`, `taxi_city`) VALUES
(1, 'Aktau'),
(2, 'Ozen');



CREATE TABLE `bookinghotel` (
`firstname` varchar(255) not null,
`tel` varchar(255) not null,
  `hotel` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `datecome` varchar(255) NOT NULL,
  `dateout` varchar(255) NOT NULL,
  `rooms` varchar(255) NOT NULL,
  `adult` varchar(255) NOT NULL,
  `children` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1

CREATE TABLE `bookingtaxi` (
  `firstname` varchar(255) not null,
  `tel` varchar(255) not null,
  `city` varchar(255) NOT NULL,
  `from` varchar(255) not null,
  `where` varchar(255) not null,
  `class` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
